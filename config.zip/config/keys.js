module.exports = {
    mongoURI: "mongodb+srv://admin:51mEHWOGDWsCN2S6@mern.25ao6.mongodb.net/PAQdb",
    secretOrKey: "q_k/KYa0qGvPz/s"
}